﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using NUnit.Framework;

namespace ClassLibrary1
{

    //[XmlRoot( "MyRoot", Namespace = "http://www.sample.com/v1.1", IsNullable = false )]
    public class PaymentCollection : Collection<Payment>
    {
    }

    //[XmlRoot( "MyRoot", Namespace = "http://www.sample.com/v1.1", IsNullable = false )]
    public class Payment
    {
        //abstract methods
        public string Prop { get; set; }
    }

    [Serializable]
    public class BankPayment : Payment
    {
        //method implementations
    }


    public class Tests
    {
        [Test]
        public static void Test()
        {
            var bankPaymentType = typeof( BankPayment );
            
            var xRoot = new XmlRootAttribute
            {
                Namespace = "ClassLibrary1",
            };

            var attributes = new XmlAttributes(){ XmlRoot = xRoot };

            attributes.XmlElements.Add( new XmlElementAttribute( bankPaymentType ) );

            var overrides = new XmlAttributeOverrides();
            overrides.Add( typeof( Payment ), attributes );
            
            var serializer = new XmlSerializer( typeof ( Payment ), overrides );

            var pay = new BankPayment();

            using ( var writer = new StringWriter() )
            {
                serializer.Serialize( writer, pay );
                Console.WriteLine( writer.ToString() );
            }


        }
    }
}
